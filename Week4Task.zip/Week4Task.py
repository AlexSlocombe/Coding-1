""" Write a program that given a list of numbers, multiply all numbers in the list. 
Bonus for ignoring non-number element. Example: input: [1, 2, 3, 4], output: 24"""

j = 1
nums=[1, 2, 3, 4]
for i in nums:
    j = i * j
print(j)


""" Start with 4 words “comfortable”, “round”, “support”, “machinery”, 
return a list of all possible 2 word combinations. 
Example: ["comfortable round", "comfortable support", "comfortable machinery", .....] """

#I heavily used the internet to help me with this one

import itertools

stuff = ["comfortable", "round", "support", "machinery"]
for L in range(0, len(stuff)+1):
    for subset in itertools.combinations(stuff, 2):
        print(subset)
